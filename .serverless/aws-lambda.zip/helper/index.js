const getMessage = async () => {
    return "hello helper function ";
}


module.exports = { getMessage }